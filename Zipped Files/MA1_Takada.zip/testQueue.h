#include "queue.h"

void testDequeueEmpty(void);
void testDequeueFull(void);
void testEnqueueEmpty(void);
void testEnqueueFull(void);
void testPeekEmpty(void);
void testPeekFull(void);

void testSize(void);
void testIsEmpty(void);
void testIsFull(void);