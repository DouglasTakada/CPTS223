// This code was taken from https://www.techiedelight.com/queue-implementation-cpp/
// The code has been modified from the original to provide opportunities to learn

#pragma once

#include <iostream>
#include <cstdlib>
//#include <limits>
//using namespace std;

using std::cout;
using std::endl;
// define default capacity of the queue
#define SIZE 10