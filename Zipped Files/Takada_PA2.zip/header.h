#pragma once

#include <algorithm>
#include <iostream>

using std::max;
using std::random_shuffle;
using std::cout;
using std::endl;