#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cstdio>

using std::cout;
using std::endl;
using std::cin;
using std::ifstream;
using std::ofstream;
using std::string;