#include "header.h"
struct myData {
	string name;
	int points;

	myData() : name(""), points(0) {//initializes all data to default values
		
	}

	void initializedata(string name, int points) {
		this->name = name;
		this->points = points;
	}

	void setpoint(int points) {
		this->points = points;
	}
};